package top.fpsmaster.prism.screen;

import java.util.ArrayList;
import java.util.List;
import top.fpsmaster.prism.canvas.FontHandle;
import top.fpsmaster.prism.icon.GlyphIcons;
import top.fpsmaster.prism.theme.Metrics;
import top.fpsmaster.prism.widget.Chrome;
import top.fpsmaster.prism.widget.Scroll;
import top.fpsmaster.prism.widget.TextFit;
import top.fpsmaster.prism.widget.UiFrame;

/** Local cosmetics catalog and equipment. Minecraft entity rendering remains in the client bridge. */
public final class SharedCosmetics {
    private static final float MAX_W = 660f;
    private static final float MAX_H = 380f;
    private static final float HEADER_H = 29f;
    private static final float TOOLBAR_H = 33f;
    private static final float CARD_H = 104f;
    private static final float GAP = 7f;
    private static final float DEFAULT_MIN_SCALE = 0.5f;
    private static final float DEFAULT_MAX_SCALE = 1.5f;

    private final Object scaleDrag = new Object();
    private final Object previewDrag = new Object();
    private final Scroll itemScroll = new Scroll(new Object());
    private float previewYaw = 180f;
    private float previewDragX;
    private float previewDragYaw;
    private boolean previewDragging;
    private String category = "all";
    private String selectedId;

    public boolean draw(UiFrame ui, CosmeticsBridge bridge) {
        float gw = ui.host().width();
        float gh = ui.host().height();
        float panelW = Math.min(MAX_W, gw - 20f);
        float panelH = Math.min(MAX_H, gh - 20f);
        float panelX = (gw - panelW) / 2f;
        float panelY = (gh - panelH) / 2f;
        List<CosmeticsBridge.Item> all = bridge.items();

        Chrome.veil(ui, 1f);
        Chrome.panel(ui, panelX, panelY, panelW, panelH);
        if (drawHeader(ui, bridge, panelX, panelY, panelW)) return true;
        ensureSelection(all, bridge);
        ensureVisibleSelection(all, bridge);

        float contentY = panelY + HEADER_H;
        float rightW = Math.max(178f, Math.min(260f, panelW * 0.39f));
        float rightX = panelX + panelW - rightW;
        Chrome.hairlineV(ui, rightX, contentY, panelH - HEADER_H);
        float catalogX = panelX + 9f;
        float catalogW = rightX - catalogX - 9f;
        drawCatalog(ui, bridge, all, catalogX, contentY, catalogW, panelH - HEADER_H - 9f);
        drawPreview(ui, bridge, all, selected(all), rightX, contentY, rightW, panelH - HEADER_H);
        return false;
    }

    private boolean drawHeader(UiFrame ui, CosmeticsBridge bridge, float x, float y, float w) {
        if (back(ui, x + 8f, y + 7f)) return true;
        FontBold.draw(ui, 17, bridge.i18n("cosmetics.title"), x + 32f, y + 8f,
                ui.theme().textPrimary());

        String custom = bridge.i18n("cosmetics.custom.open");
        FontHandle font = ui.font(12);
        boolean compact = w < 350f;
        float buttonW = compact ? 20f : Math.min(116f, font.measure(custom) + 24f);
        float buttonX = x + w - buttonW - 8f;
        boolean hover = ui.hovered(buttonX, y + 5f, buttonW, 19f);
        Chrome.button(ui, buttonX, y + 5f, buttonW, 19f, hover);
        GlyphIcons.draw(ui, "folder", buttonX + 6f, y + 11f, 7f,
                hover ? ui.theme().textPrimary() : ui.theme().textSecondary());
        if (!compact) {
            ui.canvas().drawString(font, fit(font, custom, buttonW - 22f), buttonX + 18f, y + 11f,
                    hover ? ui.theme().textPrimary() : ui.theme().textSecondary());
        }
        if (ui.clicked(buttonX, y + 5f, buttonW, 19f)) bridge.openCustomFolder();
        Chrome.hairlineH(ui, x, y + HEADER_H, w);
        return false;
    }

    private void ensureSelection(List<CosmeticsBridge.Item> items, CosmeticsBridge bridge) {
        if (find(items, selectedId) != null) return;
        for (CosmeticsBridge.Item item : items) {
            if (item.equipped()) {
                select(item, bridge);
                return;
            }
        }
        if (!items.isEmpty()) select(items.get(0), bridge);
    }

    private void ensureVisibleSelection(List<CosmeticsBridge.Item> items, CosmeticsBridge bridge) {
        List<CosmeticsBridge.Item> visible = filtered(items);
        for (CosmeticsBridge.Item item : visible) {
            // 反着比：id 为 null 的商品目前两个宿主都发不出来（都是非空 String），但
            // find() 和 drawAction 都做了 null 防护，只有这里没做——防护不一致本身就是坑，
            // 顺手统一掉，成本是零。
            if (item.id() != null && item.id().equals(selectedId)) return;
        }
        if (!visible.isEmpty()) select(visible.get(0), bridge);
    }

    private void select(CosmeticsBridge.Item item, CosmeticsBridge bridge) {
        selectedId = item.id();
        bridge.previewItem(selectedId);
    }

    private void drawCatalog(UiFrame ui, CosmeticsBridge bridge, List<CosmeticsBridge.Item> all,
                             float x, float y, float w, float h) {
        float filtersW = 132f;
        float filtersX = x;
        ui.canvas().fillRoundRect(filtersX, y + 7f, filtersW, 20f, Metrics.CTL_RADIUS,
                ui.theme().layer());
        float filterX = filtersX + 2f;
        filterX = categoryTab(ui, bridge, all, filterX, y + 9f, "all", 38f);
        filterX = categoryTab(ui, bridge, all, filterX, y + 9f, "cape", 42f);
        categoryTab(ui, bridge, all, filterX, y + 9f, "back", 44f);

        List<CosmeticsBridge.Item> visible = filtered(all);
        float listY = y + TOOLBAR_H;
        float listH = h - TOOLBAR_H;
        int columns = 2;
        float cardW = (w - GAP * (columns - 1)) / columns;
        int rows = (visible.size() + columns - 1) / columns;
        float contentH = Math.max(listH, rows * (CARD_H + GAP) - GAP);
        float scroll = itemScroll.begin(ui, x, listY, w, listH, contentH);

        if (visible.isEmpty()) {
            String empty = bridge.i18n("cosmetics.empty");
            FontHandle font = ui.font(12);
            ui.canvas().drawString(font, empty, x + (w - font.measure(empty)) / 2f,
                    listY + listH / 2f - font.lineHeight() / 2f, ui.theme().textDisabled());
        }
        for (int i = 0; i < visible.size(); i++) {
            int row = i / columns;
            int column = i % columns;
            float cardX = x + column * (cardW + GAP);
            float cardY = listY + scroll + row * (CARD_H + GAP);
            if (cardY + CARD_H < listY || cardY > listY + listH) continue;
            CosmeticsBridge.Item item = visible.get(i);
            drawItem(ui, bridge, item, cardX, cardY, cardW, CARD_H);
            if (ui.clicked(cardX, cardY, cardW, CARD_H)) select(item, bridge);
        }
        itemScroll.end(ui);
    }

    private float categoryTab(UiFrame ui, CosmeticsBridge bridge, List<CosmeticsBridge.Item> all,
                              float x, float y, String id, float w) {
        boolean selected = id.equals(category);
        boolean hover = ui.hovered(x, y, w, 16f);
        if (selected) ui.canvas().fillRoundRect(x, y, w, 16f, 4f, ui.theme().layerActive());
        FontHandle font = ui.font(12);
        String label = bridge.i18n("cosmetics.filter." + id);
        ui.canvas().drawString(font, fit(font, label, w - 6f),
                x + (w - Math.min(font.measure(label), w - 6f)) / 2f, y + 5f,
                selected || hover ? ui.theme().textPrimary() : ui.theme().textSecondary());
        if (ui.clicked(x, y, w, 16f)) {
            category = id;
            itemScroll.setOffset(0f);
            ensureVisibleSelection(all, bridge);
        }
        return x + w + 2f;
    }

    private void drawItem(UiFrame ui, CosmeticsBridge bridge, CosmeticsBridge.Item item,
                          float x, float y, float w, float h) {
        boolean selected = item.id().equals(selectedId);
        boolean hover = ui.hovered(x, y, w, h);
        if (selected) Chrome.selectedSurface(ui, x, y, w, h, Metrics.CARD_RADIUS);
        else Chrome.card(ui, x, y, w, h, hover, false);

        float footerH = 28f;
        float visualH = h - footerH;
        ui.canvas().fillRoundRect(x + 5f, y + 4f, w - 10f, visualH - 8f, 3f,
                ui.theme().layerActive());
        bridge.paintItemPreview(ui, item, x + 5f, y + 4f, w - 10f, visualH - 8f);
        Chrome.hairlineH(ui, x + 4f, y + visualH, w - 8f);

        if (item.equipped()) {
            ui.canvas().fillCircle(x + w - 10f, y + 9f, 5f, ui.theme().accent());
            GlyphIcons.draw(ui, "check", x + w - 12.5f, y + 6.5f, 5f, ui.theme().white());
        }

        String meta = item.builtin() ? bridge.i18n("cosmetics.builtin") : "";
        FontHandle metaFont = ui.font(10);
        float metaW = Math.min(metaFont.measure(meta), w * 0.42f);
        FontHandle nameFont = ui.font(14);
        String name = fit(nameFont, item.name(), w - metaW - (meta.isEmpty() ? 16f : 19f));
        // 页脚是一条 footerH 高的独立区域，名字和价签要在它里面垂直居中。原来写死的
        // +7 / +8 是按「行盒顶」量的，名字的 7px 行盒落在 [+7, +14]，而页脚中心在 +14,
        // 整块字比中线高了 3.5px，卡片看上去就是字贴着分隔线。
        float footerTop = y + visualH;
        FontBold.draw(ui, 14, name, x + 8f, Chrome.textY(footerTop, footerH, nameFont),
                ui.theme().textPrimary());
        if (!meta.isEmpty()) {
            ui.canvas().drawString(metaFont, fit(metaFont, meta, w * 0.42f), x + w - metaW - 8f,
                    Chrome.textY(footerTop, footerH, metaFont),
                    item.builtin() ? ui.theme().ok() : ui.theme().textDisabled());
        }
    }

    private void drawPreview(UiFrame ui, CosmeticsBridge bridge, List<CosmeticsBridge.Item> all,
                             CosmeticsBridge.Item item, float x, float y, float w, float h) {
        float pad = 9f;
        float innerX = x + pad;
        float innerW = w - pad * 2f;
        String name = item == null ? bridge.i18n("cosmetics.none") : item.name();
        FontBold.draw(ui, 17, fit(ui.font(17), name, innerW - 22f), innerX, y + 7f,
                ui.theme().textPrimary());
        if (item != null) {
            String meta = bridge.i18n(categoryKey(item.category()));
            ui.canvas().drawString(ui.font(12), fit(ui.font(12), meta, innerW - 22f), innerX, y + 21f,
                    ui.theme().textSecondary());
        }

        boolean resetHover = ui.hovered(x + w - 24f, y + 7f, 16f, 16f);
        Chrome.ghostButton(ui, x + w - 24f, y + 7f, 16f, 16f, resetHover);
        GlyphIcons.draw(ui, "reset", x + w - 19.5f, y + 11.5f, 7f,
                resetHover ? ui.theme().textPrimary() : ui.theme().textSecondary());
        if (ui.clicked(x + w - 24f, y + 7f, 16f, 16f)) previewYaw = 180f;

        boolean back = item != null && isBack(item.category());
        float footerH = 50f;
        float stageY = y + TOOLBAR_H;
        float stageH = h - TOOLBAR_H - footerH;
        ui.canvas().fillRect(x + 0.5f, stageY, w - 0.5f, stageH, ui.theme().layer());
        drawGrid(ui, x + 0.5f, stageY, w - 0.5f, stageH);
        rotatePreview(ui, x, stageY, w, stageH);
        bridge.paintPlayerPreview(ui, x, stageY, w, stageH, previewYaw);

        float footerY = stageY + stageH;
        Chrome.hairlineH(ui, x, footerY, w);
        if (back) drawBackSettings(ui, bridge, all, item, innerX, footerY + 7f, innerW);
        else drawCapeSettings(ui, bridge, innerX, footerY + 7f, innerW);

        String status = bridge.statusMessage();
        if (status != null && !status.isEmpty()) {
            ui.canvas().drawString(ui.font(10), fit(ui.font(10), status, innerW - 94f), innerX,
                    y + h - 17f, ui.theme().textDisabled());
        }
        drawAction(ui, bridge, item, x + w - 98f, y + h - 25f, 90f);
    }

    private void drawGrid(UiFrame ui, float x, float y, float w, float h) {
        float step = 14f;
        for (float lineX = x + step; lineX < x + w; lineX += step) {
            ui.canvas().fillRect(lineX, y, 0.5f, h, ui.theme().grid());
        }
        for (float lineY = y + step; lineY < y + h; lineY += step) {
            ui.canvas().fillRect(x, lineY, w, 0.5f, ui.theme().grid());
        }
        ui.canvas().fillRect(x + w * 0.14f, y + h * 0.9f, w * 0.72f, 0.5f, ui.theme().stroke());
    }

    private void rotatePreview(UiFrame ui, float x, float y, float w, float h) {
        boolean dragging = ui.input().beginDrag(previewDrag, 0, x, y, w, h)
                || ui.input().isDragging(previewDrag);
        if (dragging && ui.input().isButtonDown(0)) {
            if (!previewDragging) {
                previewDragX = ui.input().mouseX();
                previewDragYaw = previewYaw;
                previewDragging = true;
            }
            previewYaw = wrapDegrees(previewDragYaw + (ui.input().mouseX() - previewDragX) * 0.8f);
        } else {
            ui.input().releaseDrag(previewDrag);
            previewDragging = false;
        }
    }

    private void drawBackSettings(UiFrame ui, CosmeticsBridge bridge, List<CosmeticsBridge.Item> all,
                                  CosmeticsBridge.Item shown, float x, float y, float w) {
        FontHandle font = ui.font(12);
        CosmeticsBridge.Item policy = equippedBack(all);
        if (policy == null) policy = shown;
        float min = policy == null ? DEFAULT_MIN_SCALE : policy.minScale();
        float max = policy == null ? DEFAULT_MAX_SCALE : policy.maxScale();
        boolean adjustable = bridge.wingScaleAdjustable()
                && (policy == null || policy.allowResize())
                && max - min > 1e-4f;
        float scale = Math.max(min, Math.min(max, bridge.wingScale()));
        String scaleLabel = bridge.i18n("cosmetics.wings.scale");
        ui.canvas().drawString(font, scaleLabel, x, y + 4f,
                adjustable ? ui.theme().textSecondary() : ui.theme().textDisabled());
        String scaleValue = Math.round(scale * 100f) + "%";
        float valueW = font.measure(scaleValue);
        ui.canvas().drawString(font, scaleValue, x + w - valueW, y + 4f,
                adjustable ? ui.theme().textSecondary() : ui.theme().textDisabled());
        float sliderX = x + Math.min(74f, font.measure(scaleLabel) + 8f);
        float sliderW = Math.max(30f, w - (sliderX - x) - valueW - 7f);
        float t = track(scale, min, max);
        if (adjustable) {
            t = Chrome.slider(ui, scaleDrag, sliderX, y, sliderW, t);
            scale = min + t * (max - min);
        } else {
            Chrome.slider(ui, sliderX, y, sliderW, t, false);
        }
        if (Math.abs(scale - bridge.wingScale()) > 1e-4f) bridge.setWingScale(scale);
    }

    private CosmeticsBridge.Item equippedBack(List<CosmeticsBridge.Item> items) {
        for (CosmeticsBridge.Item item : items) {
            if (item.equipped() && isBack(item.category())) return item;
        }
        return null;
    }

    /** Maps a scale onto the 0..1 slider track, falling back to the default band when locked. */
    private float track(float scale, float min, float max) {
        if (max - min <= 1e-4f) {
            min = DEFAULT_MIN_SCALE;
            max = DEFAULT_MAX_SCALE;
        }
        return (scale - min) / (max - min);
    }

    private void drawCapeSettings(UiFrame ui, CosmeticsBridge bridge, float x, float y, float w) {
        FontHandle font = ui.font(12);
        String label = bridge.i18n("cosmetics.cape.animation");
        ui.canvas().drawString(font, label, x, y + 4f, ui.theme().textSecondary());
        boolean enabled = bridge.capeEnabled();
        boolean next = Chrome.toggle(ui, x + font.measure(label) + 7f, y, enabled);
        if (next != enabled) bridge.setCapeEnabled(next);
    }

    private void drawAction(UiFrame ui, CosmeticsBridge bridge, CosmeticsBridge.Item item,
                            float x, float y, float w) {
        if (item == null) return;
        if (item.equipped()) {
            Chrome.button(ui, x, y, w, 18f, bridge.i18n("cosmetics.equipped"),
                    Chrome.ButtonStyle.DEFAULT);
        } else if (Chrome.button(ui, x, y, w, 18f, bridge.i18n("cosmetics.equip"),
                Chrome.ButtonStyle.PRIMARY)) {
            bridge.equipItem(item.id());
        }
    }
    private List<CosmeticsBridge.Item> filtered(List<CosmeticsBridge.Item> items) {
        List<CosmeticsBridge.Item> result = new ArrayList<CosmeticsBridge.Item>();
        for (CosmeticsBridge.Item item : items) {
            if ("cape".equals(category) && !"cape".equals(item.category())) continue;
            if ("back".equals(category) && !isBack(item.category())) continue;
            result.add(item);
        }
        return result;
    }

    private CosmeticsBridge.Item selected(List<CosmeticsBridge.Item> items) {
        return find(items, selectedId);
    }

    private CosmeticsBridge.Item find(List<CosmeticsBridge.Item> items, String id) {
        if (id == null) return null;
        for (CosmeticsBridge.Item item : items) if (id.equals(item.id())) return item;
        return null;
    }

    private boolean isBack(String itemCategory) {
        return "wings".equals(itemCategory) || "elytra".equals(itemCategory);
    }

    private String categoryKey(String itemCategory) {
        return "cape".equals(itemCategory) ? "cosmetics.cape" : "cosmetics.wings";
    }

    private String fit(FontHandle font, String value, float maxWidth) {
        return TextFit.ellipsize(font, value, maxWidth);
    }

    private float wrapDegrees(float degrees) {
        float wrapped = degrees % 360f;
        return wrapped < 0f ? wrapped + 360f : wrapped;
    }

    private boolean back(UiFrame ui, float x, float y) {
        boolean hover = ui.hovered(x, y, 16f, 16f);
        Chrome.ghostButton(ui, x, y, 16f, 16f, hover);
        GlyphIcons.draw(ui, "back", x + 4.5f, y + 4.5f, 7f,
                hover ? ui.theme().textPrimary() : ui.theme().textSecondary());
        return ui.clicked(x, y, 16f, 16f);
    }
}
